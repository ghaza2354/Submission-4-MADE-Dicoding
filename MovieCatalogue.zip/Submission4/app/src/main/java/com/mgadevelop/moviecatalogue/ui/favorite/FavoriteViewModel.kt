package com.mgadevelop.moviecatalogue.ui.favorite

import android.app.Application
import androidx.lifecycle.AndroidViewModel


class FavoriteViewModel(application: Application) : AndroidViewModel(application)