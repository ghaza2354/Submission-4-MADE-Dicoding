package com.mgadevelop.moviecatalogue.ui.movies.detailmovie

import androidx.lifecycle.ViewModel
import com.mgadevelop.moviecatalogue.ui.movies.pojo.ResultsItem

class DetailMovieViewModel : ViewModel() {
    var resultsItem: ResultsItem? = null
}