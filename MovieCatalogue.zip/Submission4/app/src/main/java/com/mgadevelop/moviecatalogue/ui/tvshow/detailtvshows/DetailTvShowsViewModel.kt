package com.mgadevelop.moviecatalogue.ui.tvshow.detailtvshows

import androidx.lifecycle.ViewModel
import com.mgadevelop.moviecatalogue.ui.tvshow.pojo.ResultsItem

class DetailTvShowsViewModel : ViewModel() {
    var resultsItem: ResultsItem? = null
}
